
-- НАМЕРЕННЫЕ ОШИБКИ в начальной схеме (будут исправлены через ALTER TABLE/RENAME):
--  [1] Три таблицы созданы с неверными именами: customers, orders, order_items
--  [2] product.price — тип INT вместо DECIMAL(10,2)
--  [3] Таблица product — отсутствует столбец unit
--  [4] Таблица supply  — отсутствует столбец total_cost
--  [5] Таблица customers — лишний столбец age INT
--  [6] product.supplier_id — нет FK-ограничения
--  [7] payment.order_id   — нет FK-ограничения
--  [8] order_items.product_id — FK без ON DELETE RESTRICT
--  [9] supply_item — составной PRIMARY KEY (supply_id, product_id) вместо supply_item_id
--  [10] product.price — нет CHECK (price > 0); customers.phone — нет UNIQUE
--


-- СОЗДАНИЕ БАЗЫ ДАННЫХ

CREATE DATABASE Asian_Sweets_Shop
    WITH ENCODING    = 'UTF8'
         LC_COLLATE  = 'ru_RU.UTF-8'
         LC_CTYPE    = 'ru_RU.UTF-8'
         TEMPLATE    = template0;




-- СОЗДАНИЕ ТАБЛИЦ 


-- ── ENUM-типы 
CREATE TYPE customer_type_enum AS ENUM ('individual', 'company');
CREATE TYPE order_status_enum  AS ENUM ('pending', 'confirmed', 'shipped', 'delivered', 'cancelled');


-- ── Таблица категорий 
CREATE TABLE category (
    category_id SERIAL       PRIMARY KEY,
    name        VARCHAR(100) NOT NULL UNIQUE,
    description TEXT
);


-- ── Таблица поставщиков 
CREATE TABLE supplier (
    supplier_id    SERIAL       PRIMARY KEY,
    company_name   VARCHAR(200) NOT NULL,
    country        VARCHAR(100),
    contact_person VARCHAR(150),
    phone          VARCHAR(30),
    email          VARCHAR(150)
);


-- ── [1, 5] Клиенты: имя "customers", лишний столбец age, нет UNIQUE на phone 
CREATE TABLE customers (
    customer_id   SERIAL             PRIMARY KEY,
    full_name     VARCHAR(200)       NOT NULL,
    customer_type customer_type_enum NOT NULL DEFAULT 'individual',
    phone         VARCHAR(30)        NOT NULL,          -- [10] нет UNIQUE — исправим через ALTER
    email         VARCHAR(150)       UNIQUE,
    address       TEXT,
    age           INT                                   -- [5] лишний столбец — удалим через ALTER
);


-- ── Таблица сотрудников 
CREATE TABLE employee (
    employee_id SERIAL       PRIMARY KEY,
    full_name   VARCHAR(200) NOT NULL,
    position    VARCHAR(100),
    phone       VARCHAR(30),
    email       VARCHAR(150) UNIQUE
);


-- ── [2, 3, 6] Товары: price=INT, нет unit, нет FK на supplier_id 
CREATE TABLE product (
    product_id        SERIAL       PRIMARY KEY,
    name              VARCHAR(200) NOT NULL,
    description       TEXT,
    price             INT          NOT NULL,            -- [2] должен быть DECIMAL(10,2)
    country_of_origin VARCHAR(100),
    -- [3] отсутствует столбец unit — добавим через ALTER TABLE
    stock_quantity    INT          NOT NULL DEFAULT 0,
    category_id       INT,
    supplier_id       INT,                              -- [6] нет FK — добавим через ALTER TABLE
    CONSTRAINT fk_product_category
        FOREIGN KEY (category_id) REFERENCES category(category_id)
);


-- ── [4] Поставки: нет столбца total_cost 
CREATE TABLE supply (
    supply_id   SERIAL    PRIMARY KEY,
    supplier_id INT       NOT NULL,
    supply_date TIMESTAMP NOT NULL DEFAULT NOW(),
    -- [4] отсутствует total_cost — добавим через ALTER TABLE
    CONSTRAINT fk_supply_supplier
        FOREIGN KEY (supplier_id) REFERENCES supplier(supplier_id)
);


-- ── [9] Позиции поставок: составной PK (supply_id, product_id) вместо supply_item_id
-- supply_item_id объявлен как SERIAL (автоинкремент), но PRIMARY KEY — составной
CREATE TABLE supply_item (
    supply_item_id SERIAL NOT NULL,                                 -- авто-инкремент, но НЕ PK
    supply_id      INT    NOT NULL,
    product_id     INT    NOT NULL,
    quantity       INT    NOT NULL CHECK (quantity > 0),
    CONSTRAINT pk_supply_item PRIMARY KEY (supply_id, product_id),  -- [9] составной PK — заменим
    CONSTRAINT fk_si_supply  FOREIGN KEY (supply_id)  REFERENCES supply(supply_id),
    CONSTRAINT fk_si_product FOREIGN KEY (product_id) REFERENCES product(product_id)
);


-- ── [1] Заказы: имя "orders" 
CREATE TABLE orders (
    order_id     SERIAL             PRIMARY KEY,
    order_date   TIMESTAMP          NOT NULL DEFAULT NOW(),
    status       order_status_enum  NOT NULL DEFAULT 'pending',
    total_amount DECIMAL(12,2)      NOT NULL DEFAULT 0,
    customer_id  INT                NOT NULL,
    employee_id  INT,
    CONSTRAINT fk_orders_customer
        FOREIGN KEY (customer_id) REFERENCES customers(customer_id),
    CONSTRAINT fk_orders_employee
        FOREIGN KEY (employee_id) REFERENCES employee(employee_id)
);


-- ── [1, 8] Позиции заказов: имя "order_items", FK на product без ON DELETE ──
CREATE TABLE order_items (
    order_item_id   SERIAL        PRIMARY KEY,
    order_id        INT           NOT NULL,
    product_id      INT           NOT NULL,
    quantity        INT           NOT NULL CHECK (quantity > 0),
    price_at_moment DECIMAL(10,2) NOT NULL,
    CONSTRAINT fk_oi_order
        FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE,
    CONSTRAINT fk_oi_product
        FOREIGN KEY (product_id) REFERENCES product(product_id)    -- [8] нет ON DELETE RESTRICT
);


-- ── [7] Платежи: нет FK на order_id 
CREATE TABLE payment (
    payment_id     SERIAL        PRIMARY KEY,
    order_id       INT           NOT NULL,               -- [7] нет FK — добавим через ALTER
    payment_date   TIMESTAMP     NOT NULL DEFAULT NOW(),
    amount         DECIMAL(12,2) NOT NULL CHECK (amount > 0),
    payment_method VARCHAR(50)   NOT NULL
);



-- ВСТАВКА ДАННЫХ 
-- Таблицы еще не переименованы; столбец age ещё существует в customer.


-- INSERT 1: Категории товаров
INSERT INTO category (name, description) VALUES
    ('Японские сладости',   'Традиционные японские десерты: моти, вагаси, дайфуку'),
    ('Корейские сладости',  'Корейские снеки и десерты: Пеперо, Хонэи, Чок Пай'),
    ('Китайские сладости',  'Популярные китайские сладости и печенье'),
    ('Напитки',             'Азиатские газированные напитки и холодные чаи'),
    ('Снеки',               'Солёные закуски и чипсы из Азии');


-- INSERT 2: Поставщики
INSERT INTO supplier (company_name, country, contact_person, phone, email) VALUES
    ('Sakura Import Ltd.',    'Япония',   'Ямамото Кэндзи',  '+81-90-1234-5678',  'yamamoto@sakura-import.jp'),
    ('Seoul Goods Co.',       'Корея',    'Ким Минджун',     '+82-10-9876-5432',  'minjun.kim@seoulgoods.kr'),
    ('Dragon Trade Group',    'Китай',    'Чэнь Лэй',        '+86-139-0000-1234', 'chen.lei@dragontrade.cn'),
    ('Asia Beverages LLC',    'Тайланд',  'Priya Somsak',    '+66-81-555-0099',   'priya@asiabev.th');


-- INSERT 3: Клиенты (age ещё существует — будет удалён в ALTER TABLE)
INSERT INTO customers (full_name, customer_type, phone, email, address, age) VALUES
    ('Иванова Мария Сергеевна',  'individual', '+7-916-111-2233', 'ivanova.ms@mail.ru',
     'г. Москва, ул. Ленина, д. 15, кв. 7',            28),
    ('ООО «АзияМаркет»',         'company',    '+7-495-800-0055', 'orders@asiamarket.ru',
     'г. Москва, пр-т Мира, д. 100',                    NULL),
    ('Петров Алексей Иванович',  'individual', '+7-916-222-3344', 'petrov.ai@gmail.com',
     'г. Санкт-Петербург, ул. Невская, д. 5, кв. 12',  35),
    ('Сидорова Анна Викторовна', 'individual', '+7-916-333-4455', 'sidorova.av@yandex.ru',
     'г. Москва, ул. Тверская, д. 8, кв. 22',           24);


-- INSERT 4: Сотрудники
INSERT INTO employee (full_name, position, phone, email) VALUES
    ('Козлова Ольга Дмитриевна', 'Менеджер по продажам', '+7-916-444-5566', 'kozlova@sweetshop.ru'),
    ('Волков Сергей Павлович',   'Кладовщик',            '+7-916-555-6677', 'volkov@sweetshop.ru'),
    ('Морозова Елена Игоревна',  'Администратор',         '+7-916-666-7788', 'morozova@sweetshop.ru');


-- INSERT 5: Товары
-- (price пока INT — [2]; unit отсутствует — [3]; supplier_id без FK — [6])
INSERT INTO product (name, description, price, country_of_origin, stock_quantity, category_id, supplier_id)
VALUES
    ('Моти клубничные',        '6 шт., начинка — клубника со сливками, 150 г', 350,  'Япония',  120, 1, 1),
    ('Пеперо шоколадное',      'Соломка в шоколаде, 47 г',                      89,  'Корея',   250, 2, 2),
    ('Рамунэ дыня',            'Японский газированный напиток, 200 мл',          150, 'Япония',  180, 4, 1),
    ('Чипсы нори',             'Закуска из морских водорослей, 20 г',             75, 'Корея',   310, 5, 2),
    ('Моти манго',             '6 шт., начинка — манго, 150 г',                 350,  'Китай',    95, 3, 3),
    ('Тайский чай с молоком',  'Готовый тайский молочный чай, 230 мл',           120, 'Тайланд', 200, 4, 4);


-- INSERT 6: Поставки (total_cost отсутствует — [4])
INSERT INTO supply (supplier_id, supply_date) VALUES
    (1, '2026-03-15 10:00:00'),
    (2, '2026-03-20 14:30:00'),
    (3, '2026-04-01 09:00:00');


-- INSERT 7: Позиции поставок
-- (supply_item имеет составной PK — пары (supply_id, product_id) уникальны)
INSERT INTO supply_item (supply_id, product_id, quantity) VALUES
    (1, 1, 60),
    (1, 3, 100),
    (2, 2, 150),
    (2, 4, 200),
    (3, 5, 80);


-- INSERT 8: Заказы (таблица уже переименована в customer_order)
INSERT INTO orders (order_date, status, total_amount, customer_id, employee_id) VALUES
    ('2026-04-05 11:20:00', 'confirmed', 1249.00, 1, 1),
    ('2026-04-06 13:45:00', 'pending',    535.00, 3, 1),
    ('2026-04-07 16:00:00', 'shipped',   2100.00, 2, 3);


-- INSERT 9: Позиции заказов (таблица еще не переименована в order_item)
INSERT INTO order_items (order_id, product_id, quantity, price_at_moment) VALUES
    (1, 1, 2, 350.00),
    (1, 3, 2, 150.00),
    (1, 2, 1,  89.00),
    (2, 4, 3,  75.00),
    (2, 2, 2,  89.00),
    (3, 1, 3, 350.00),
    (3, 5, 2, 350.00),
    (3, 6, 2, 120.00);


-- INSERT 10: Платежи (order_id без FK — [7]; FK добавим через ALTER)
INSERT INTO payment (order_id, payment_date, amount, payment_method) VALUES
    (1, '2026-04-05 11:25:00', 1249.00, 'card'),
    (3, '2026-04-07 16:10:00', 1000.00, 'cash'),
    (3, '2026-04-08 09:00:00', 1100.00, 'card');



-- ИЗМЕНЕНИЕ ТАБЛИЦ
-- Выполняется на уже заполненных таблицах.

--  ПЕРЕИМЕНОВАНИЕ ТАБЛИЦ 


--  Исправляем имя: customers → customer
ALTER TABLE customers   RENAME TO customer;

--  Исправляем имя: orders → customer_order
ALTER TABLE orders      RENAME TO customer_order;

--  Исправляем имя: order_items → order_item
ALTER TABLE order_items RENAME TO order_item;


-- ДОБАВЛЕНИЕ СТОЛБЦОВ 

-- ALTER 1: Добавить столбец unit в product [исправляет [3]]
ALTER TABLE product
    ADD COLUMN unit VARCHAR(50);

-- Заполним unit для уже существующих товаров
UPDATE product SET unit = CASE
    WHEN name LIKE '%мл%' OR name LIKE '%напит%' OR name LIKE '%чай%' THEN 'мл'
    WHEN name LIKE '%г%'  OR name LIKE '%чипсы%' OR name LIKE '%снек%' THEN 'г'
    ELSE 'шт.'
END;


-- ALTER 2: Добавить столбец total_cost в supply [исправляет [4]]
ALTER TABLE supply
    ADD COLUMN total_cost DECIMAL(12,2);

-- Рассчитаем total_cost для уже существующих поставок
UPDATE supply s
SET total_cost = (
    SELECT SUM(p.price * si.quantity)
    FROM supply_item si
    JOIN product p ON p.product_id = si.product_id
    WHERE si.supply_id = s.supply_id
);


-- ИЗМЕНЕНИЕ И УДАЛЕНИЕ СТОЛБЦОВ 

-- ALTER 3: Изменить тип price с INT на DECIMAL(10,2) [исправляет [2]]
ALTER TABLE product
    ALTER COLUMN price TYPE DECIMAL(10,2)
    USING price::DECIMAL(10,2);


-- ALTER 4: Удалить лишний столбец age из customer [исправляет [5]]
ALTER TABLE customer
    DROP COLUMN age;


-- ДОБАВЛЕНИЕ ВНЕШНИХ КЛЮЧЕЙ 

-- ALTER 5: Добавить FK для product.supplier_id → supplier [исправляет [6]]
ALTER TABLE product
    ADD CONSTRAINT fk_product_supplier
        FOREIGN KEY (supplier_id) REFERENCES supplier(supplier_id);


-- ALTER 6: Добавить FK для payment.order_id → customer_order [исправляет [7]]
ALTER TABLE payment
    ADD CONSTRAINT fk_payment_order
        FOREIGN KEY (order_id) REFERENCES customer_order(order_id)
        ON DELETE RESTRICT;


-- ИЗМЕНЕНИЕ ВНЕШНЕГО КЛЮЧА 

-- ALTER 7: Перенастроить FK product_id в order_item — добавить ON DELETE RESTRICT
--          (исправляет [8]: FK существовал, но без явного ON DELETE)
ALTER TABLE order_item
    DROP CONSTRAINT fk_oi_product,
    ADD  CONSTRAINT fk_oi_product
        FOREIGN KEY (product_id) REFERENCES product(product_id)
        ON DELETE RESTRICT;


-- ИЗМЕНЕНИЕ ПЕРВИЧНОГО КЛЮЧА 

-- ALTER 8: Заменить составной PK (supply_id, product_id) на единственный
--          PK по supply_item_id [исправляет [9]]
ALTER TABLE supply_item
    DROP CONSTRAINT pk_supply_item,
    ADD  PRIMARY KEY (supply_item_id);


--ДОБАВЛЕНИЕ ДРУГИХ ОГРАНИЧЕНИЙ 

-- ALTER 9: Добавить UNIQUE на customer.phone [исправляет [10]]
ALTER TABLE customer
    ADD CONSTRAINT uq_customer_phone UNIQUE (phone);


-- ALTER 10: Добавить CHECK на product.price — цена должна быть > 0 [исправляет [10]]
ALTER TABLE product
    ADD CONSTRAINT chk_product_price CHECK (price > 0);




-- Удаление таблиц (в порядке зависимостей — сначала дочерние)
DROP TABLE IF EXISTS payment        CASCADE;
DROP TABLE IF EXISTS order_item     CASCADE;
DROP TABLE IF EXISTS customer_order CASCADE;
DROP TABLE IF EXISTS supply_item    CASCADE;
DROP TABLE IF EXISTS supply         CASCADE;
DROP TABLE IF EXISTS product        CASCADE;
DROP TABLE IF EXISTS employee       CASCADE;
DROP TABLE IF EXISTS customer       CASCADE;
DROP TABLE IF EXISTS supplier       CASCADE;
DROP TABLE IF EXISTS category       CASCADE;

-- Удаление ENUM-типов
DROP TYPE IF EXISTS order_status_enum;
DROP TYPE IF EXISTS customer_type_enum;

-- Удаление базы данных
-- Выполнять из другой БД 
DROP DATABASE IF EXISTS Asian_Sweets_Shop;
